# Task 1: Diagnostic Enhancement of Chest X-Rays

## Overview
Raw chest X-rays are often severely underexposed, hiding lung structure and
potential fluid build-up. This pipeline mathematically enhances a sample
grayscale X-ray so that structures become clearly visible.

## Data
`data/sample_xray.png` — a single-channel, deliberately underexposed sample
chest X-ray (intensities compressed into roughly the 0-65 range out of 255)
used to demonstrate the pipeline. To run against the full dataset, download it
from Kaggle and point `DATA_PATH` in the notebook at any image inside it:

- Dataset: COVID19+PNEUMONIA+NORMAL Chest X-Ray Image Dataset
- Link: https://www.kaggle.com/datasets/sachinkumar413/covid-pneumonia-normal-chest-xray-images

## Processing Pipeline (`xray_enhancement.ipynb`)
1. **Load and Display** — read the raw grayscale image and inspect its
   intensity range.
2. **Histogram Equalization** — `cv2.equalizeHist()` redistributes pixel
   intensities across the full range, immediately revealing rib and lung
   boundaries that were nearly invisible in the raw scan.
3. **Color Mapping** — `cv2.applyColorMap(..., cv2.COLORMAP_JET)` converts the
   equalized image into a false-color heatmap so subtle intensity differences
   (potential fluid boundaries) are easier for the eye to pick out.
4. **Color Balance** — a gray-world balance neutralizes any artificial color
   cast introduced by the JET colormap.
5. **Color Filtering (Thresholding)** — a strict binary threshold on the
   equalized image isolates only the densest tissue (bone-level intensities).
6. **Logarithmic Transformation** — `s = c*log(1+r)` expands the dark
   background of the raw image, pulling out the faint outer ribcage edges.
7. **Power-Law (Gamma) Transformation** — `s = c*r^gamma` with `gamma = 0.5`
   fine-tunes midtones, softening bone contrast so lung tissue reads more
   clearly.

## Outputs
All intermediate and final results are saved to `output/`:
- `01_raw_xray.png` — raw image
- `02_raw_vs_equalized.png`, `02b_histograms.png` — equalization comparison
- `03_heatmap.png` — JET colormap
- `04_color_balance.png` — before/after color balance
- `05_thresholding.png` — dense-tissue mask
- `06_log_transform.png` — log-transformed image
- `07_gamma_transform.png` — gamma-transformed image
- `08_full_pipeline_summary.png` — all stages side by side

## Requirements
See the root `requirements.txt`. Run with:
```bash
pip install -r ../requirements.txt
jupyter notebook xray_enhancement.ipynb
```
