# Task 2: Multi-Modal Cardiac Image Fusion

Not yet completed. Will fuse paired CT and MRI heart slices (histogram
equalization, JET color mapping, `cv2.addWeighted()` fusion, log/gamma
correction) once this task is started.
