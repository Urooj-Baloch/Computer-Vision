# Task 3: Real-Time Echocardiogram Video Analysis

Not yet completed. Will build a real-time OpenCV pipeline over an ultrasound
.mp4 (histogram equalization, JET color mapping, color balance, log/gamma
transforms) displayed side by side with the raw feed, once this task is started.
